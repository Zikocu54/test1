export function Footer() {
  return (
    <footer className="border-t border-zinc-800 mt-10 py-6 text-center text-sm text-zinc-400">
      CasinoFun © 2025. All rights reserved.
    </footer>
  );
}
